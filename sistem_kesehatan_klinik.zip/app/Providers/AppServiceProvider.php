<?php

namespace App\Providers;

use Illuminate\Support\ServiceProvider;
use App\Models\User;
use Illuminate\Support\Facades\Gate;

class AppServiceProvider extends ServiceProvider
{
    /**
     * Register any application services.
     */
    public function register(): void
    {
        //
    }

    /**
     * Bootstrap any application services.
     */
    public function boot(): void
    {
        // authorize admin
        Gate::define('Admin', function (User $user) {
            return $user->Authorize === "Admin";
        });
        Gate::define('Dokter', function (User $user) {
            return $user->Authorize === "Dokter";
        });
    }
    
}
