<script>
    async sendTimeStamp() => {
        try {
            let waktu = Math.floor(Date.now() / 1000)
            let dataSend = { timestamponline: waktu }
            let res = await fetch('<?php echo e(route('logincheck.check')); ?>', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').getAttribute('content')
                },
                body: json.stringify(dataSend),
            })
            let data = await res.json()
        } catch (error) {
            console.log("informasi login Error")
        }

        let data = await res.json()
    }
    sendTimeStamp()
    setInterval(sendTimeStamp, 60000)
</script><?php /**PATH D:\xamppMuaz\htdocs\sistem_kesehatan_klinik\resources\views/auth/status.blade.php ENDPATH**/ ?>