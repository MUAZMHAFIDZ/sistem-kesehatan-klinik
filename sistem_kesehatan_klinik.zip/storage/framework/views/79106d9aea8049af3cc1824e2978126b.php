







<div class="hapusdokter" id="hapusantrian">
    <div class="modal-content"> <!-- Diganti dengan kelas Bootstrap modal-content -->
        <div class="modal-body"> <!-- Diganti dengan kelas Bootstrap modal-body -->
            <p>Apakah anda yakin ingin menghapus data antrian berikut?</p>
            <div id="hapusdatanya">
            <p>Nama    : <span id="namaAntrian"></span></p>
            <p>Layanan : <span id="layananAntrian"></span></p>
            </div>
            <div id="tombol-confirm">
                <form id="hapusantrianform" method="POST" action="">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
                    <button type="submit" class="btn btn-danger">Hapus</button> <!-- Diganti dengan kelas Bootstrap btn-danger -->
                </form>
                <button type="button" class="btn btn-primary" onclick="batalHapus(event)">Batal</button> <!-- Diganti dengan kelas Bootstrap btn-primary -->
            </div>
        </div>
    </div>
</div><?php /**PATH D:\xamppMuaz\htdocs\sistem_kesehatan_klinik\resources\views/admin/crudantrian/hapusantrian.blade.php ENDPATH**/ ?>