<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <?php echo $__env->make('component.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;
</body>
</html><?php /**PATH D:\MuazXAMPP\htdocs\sistem_kesehatan_klinik\resources\views/dashboard.blade.php ENDPATH**/ ?>