<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Official Website Klinik Dental Care</title>
    <link rel="stylesheet" href="/css/pasien/dashboard-pasien.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap" rel="stylesheet">
</head>
<body>
    <?php echo $__env->make('pasien.layout.navbarDashboardPasien', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    
    <div class="dashContent">
      
    <div class="">
        <div class="header">
            <span>Welcome to Official</span>
            <span>Dental Care</span>
            <span>Website</span>
        </div>

        

    </div>

</body>
</html><?php /**PATH D:\MuazXAMPP\htdocs\sistem_kesehatan_klinik\resources\views/dashboard-pasien.blade.php ENDPATH**/ ?>