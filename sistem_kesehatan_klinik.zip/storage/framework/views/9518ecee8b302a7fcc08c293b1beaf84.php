<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard-Admin | Home</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <link rel="stylesheet" href="<?php echo e(asset('css/app.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/dashboard-admin.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/admin/home.css')); ?>">
</head>
<body>
    <?php echo $__env->make('admin.component.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;
    <div id="content" class="content">
        
    <!-- ========================== pasien hari ini ========================== -->
    <div class="home">
        <div class="item">
            <div class="headcard">
                <p>Pasien Hari Ini</p>
            </div>
            <div class="card">
                <?php $__currentLoopData = $pasienHariIni; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $phi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="data">
                    <p><?php echo e($phi->nama); ?></p>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
        <!-- ========================== dokter bertugas hari ini ========================== -->
        <div class="item">
            <div class="headcard">
                <p>Dokter Bertugas Hari ini</p>
            </div>
            <div class="card">
                <?php $__currentLoopData = $dokterBertugas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $activeDT): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="data">
                    <p>dr. <?php echo e($activeDT->users->fullname); ?> <span> | <?php echo e($activeDT->$hariIni); ?></span></p>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
        <!-- ========================== dokter aktif ========================== -->
        <div class="item">
            <div class="headcard">
                <p>Dokter Online</p>
            </div>
            <div class="card">
                <?php $__currentLoopData = $activeDokter; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $activeD): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="data">
                    <p>dr. <?php echo e($activeD->fullname); ?></p>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
        <!-- ========================== admin aktif ========================== -->
        <div class="item">
            <div class="headcard">
                <p>Admin Online</p>
            </div>
            <div class="card">
                <?php $__currentLoopData = $activeAdmin; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $activeA): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="data">
                    <p><?php echo e($activeA->username); ?></p>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
        <!-- ========================== survey pasien ========================== -->
        <div class="itemlong">
            <div class="headcard">
                <p>Jumlah Pasien</p>
            </div>
            <div class="card">
                <div class="data">
                    <p>Dalam Sehari</p>
                    <div class="percent1"><p><?php echo e($pasienPerHari); ?></p></div>
                </div>
                <div class="data">
                    <p>Dalam Seminggu</p>
                    <div class="percent2"><p><?php echo e($pasienPerMinggu); ?></p></div>
                </div>
                <div class="data">
                    <p>Dalam Sebulan</p>
                    <div class="percent3"><p><?php echo e($pasienPerBulan); ?></p></div>
                </div>
            </div>
        </div>
        <!-- ========================== absen dokter ========================== -->
        <div class="item">
            <div class="headcard">
                <p>Absensi Dokter</p>
            </div>
            <div class="card">
                <div class="data">
                    <p>dr. xxx <span>( Hadir )</span></p>
                </div>
            </div>
        </div>
        <!-- ========================== pasien dalam antrian ========================== -->
        <div class="item">
            <div class="headcard">
                <p>Pasien dalam Antrian</p>
            </div>
            <div class="card">
                <div class="data">
                    <p>xxxx</p>
                </div>
            </div>
        </div>
    </div>
    
    </div>
    <script>
        document.addEventListener("DOMContentLoaded", () => {
            activeMenu('menu1')
        })
    </script>
</body>
</html><?php /**PATH D:\xamppMuaz\htdocs\sistem_kesehatan_klinik\resources\views/admin/home.blade.php ENDPATH**/ ?>