<div class="hapusdokter" id="hapusdokter">
    <div class="popuphapus">
        <p>Anda yakin ? Data akan hilang Permanent!</p>
        <div>
            <form id="hapusdokterform" method="POST" action="<?php echo e(route('deletedokter.submit', ':id')); ?>">
                <?php echo csrf_field(); ?>
                <?php echo method_field('DELETE'); ?>
                <button type="submit" class="red">iya</button>
            </form>
            <button type="button" class="blue" onclick="batalHapus(event)">tidak</button>
        </div>
    </div>
</div><?php /**PATH D:\xamppMuaz\htdocs\sistem_kesehatan_klinik\resources\views/admin/cruddokter/hapusdokter.blade.php ENDPATH**/ ?>