<nav>
    <div class="logo">
        <div class="img">
            <img src="<?php echo e(asset('logo.png')); ?>" alt="">
        </div>
        <div class="account">
            <span>admin - michaeljackson</span>
            <img src="<?php echo e(asset('image/admin/admin-artoria.jpg')); ?>" alt="">
        </div>
    </div>
    <div class="navbar">
        <ul>
            <li><a id="menu1" href="<?php echo e(route('admin.menu1')); ?>"><i class="fa-solid fa-house"></i><span>Dashboard</span></a></li>
            <li><a id="menu2" href="<?php echo e(route('admin.menu2')); ?>"><i class="fa-solid fa-user"></i><span>Profil</span></a></li>
            <li><a id="menu3" href="<?php echo e(route('admin.menu3')); ?>"><i class="fa-solid fa-calendar"></i><span>Jadwal Dokter</span></a></li>
            <li><a id="menu4" href="<?php echo e(route('admin.menu4')); ?>"><i class="fa-solid fa-pills"></i><span>Stok Obat</span></a></li>
            <!-- <li><a id="menu5" href="#"><i class="fa-solid fa-file-medical"></i><span>Data Pasien</span></a></li>
            <li><a id="menu6" href="#"><i class="fa-solid fa-id-card"></i><span>Antrian Pasien</span></a></li>
            <li><a id="menu7" href="#"><i class="fa-solid fa-book-medical"></i><span>Riwayat Pasien</span></a></li>
            <li><a id="menu8" href="#"><i class="fa-solid fa-print"></i><span>Cetak Laporan</span></a></li> -->
           
            <li class="out"><a href="#"><i class="fa-solid fa-arrow-right-from-bracket"></i> <span>Keluar</span></a></li>
        </ul>
    </div>


    <!-- <div class="navbar">
        <ul>
            <li><a id="menu1" onClick="activeMenu('menu1')" href="#"><i class="fa-solid fa-house"></i><span>Dashboard</span></a></li>
            <li><a id="menu2" onClick="activeMenu('menu2')" href="#"><i class="fa-solid fa-user"></i><span>Profil</span></a></li>
            <li><a id="menu3" onClick="activeMenu('menu3')" href="#"><i class="fa-solid fa-calendar"></i><span>Jadwal Dokter</span></a></li>
            <li><a id="menu4" onClick="activeMenu('menu4')" href="#"><i class="fa-solid fa-pills"></i><span>Stok Obat</span></a></li>
            <li><a id="menu5" onClick="activeMenu('menu5')" href="#"><i class="fa-solid fa-file-medical"></i><span>Data Pasien</span></a></li>
            <li><a id="menu6" onClick="activeMenu('menu6')" href="#"><i class="fa-solid fa-id-card"></i><span>Antrian Pasien</span></a></li>
            <li><a id="menu7" onClick="activeMenu('menu7')" href="#"><i class="fa-solid fa-book-medical"></i><span>Riwayat Pasien</span></a></li>
            <li><a id="menu8" onClick="activeMenu('menu8')" href="#"><i class="fa-solid fa-print"></i><span>Cetak Laporan</span></a></li>
           
            <li class="out"><a href="#"><i class="fa-solid fa-arrow-right-from-bracket"></i> <span>Keluar</span></a></li>
        </ul>
    </div> -->
</nav><?php /**PATH D:\MuazXAMPP\htdocs\sistem_kesehatan_klinik\resources\views/component/navbar.blade.php ENDPATH**/ ?>