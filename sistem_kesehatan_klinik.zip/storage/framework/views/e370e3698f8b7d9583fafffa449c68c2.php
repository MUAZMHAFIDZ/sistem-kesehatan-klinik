<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard-Admin | Profil</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="<?php echo e(asset('css/dashboard-admin.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/admin/profile.css')); ?>">
    <style>
        a {
            left: -100px;
        }
        ul,li {
            padding-left: 0;
        }
    </style>
</head>
<body>
    <?php echo $__env->make('admin.component.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;
    
<div id="content" class="content container-fluid">
        <!-- Halaman Profil -->
    
  <div class="container-fluid p-5 haloh">
    <div id="profil" class="row justify-content-center no-gutters">
      <div class="col col-md-5">
        <div class="profile-card text-center p-5 first">
          <img src="<?php echo e($user->image); ?>" alt="Profile Picture" class="profile-picture mb-3">
          <h2 class="mb-3"><?php echo e($user->fullname); ?></h2>
          <p class="lead"><p><?php echo e($profil->deskripsi); ?></p></p>
          <ul class="list-inline">
            <a href="#"><li class="fab fa-facebook"></li></a>
            <a href="#"><li class="fab fa-instagram"></li></a>
          </ul>
        </div>
      </div>
      <div class="col col-md-5">
        <div class="profile-card text-start p-5 second">
          <h6>Pengalaman Kerja</h6>
            <?php if($profil->pengalaman): ?>
                <?php $pengalaman = json_decode($profil->pengalaman, true); ?>
                <?php $__currentLoopData = $pengalaman; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <p>- <?php echo e($item); ?></p>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php else: ?>
                <p>Tidak ada pengalaman yang tersedia.</p>
            <?php endif; ?>
          <h6>Riwayat Pendidikan</h6>
          <?php if($profil->pendidikan): ?>
              <?php $pendidikan = json_decode($profil->pendidikan, true); ?>
              <?php $__currentLoopData = $pendidikan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $items): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <p>- <?php echo e($items); ?></p>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          <?php else: ?>
              <p>Tidak ada pengalaman yang tersedia.</p>
          <?php endif; ?>
          <h6>Email</h6>
          <p><?php echo e($profil->email); ?></p>
          <h6>No Telepon</h6>
          <p>+62 <?php echo e($user->nohp); ?></p>
          <h6>Alamat</h6>
          <p><?php echo e($profil->alamat); ?></p>
        </div>
      </div>
      <div class="col col-md-2">
        <div class="profile-card text-start p-5 third">
            <button id="editButton" class="btn btn-primary">Edit Profil</button>
        </div>
      </div>
    </div>

    <form id="edit" class="row justify-content-center no-gutters sembunyikan" method="POST" action="<?php echo e(route('admin.profil.update', ['id' => $user->id])); ?>" enctype="multipart/form-data">
    <?php echo csrf_field(); ?>
    <input type="hidden" name="_method" value="PUT">

    <input type="hidden" name="idadmin" value="<?php echo e($user->id); ?>">
      <div class="col col-md-5">
        <div class="profile-card text-start p-5 first">
          <div class="form-group">
            <label for="gambar">Gambar Profil</label>
            <input type="file" class="form-control-file" id="gambar" name="image">
          </div>
          <div class="form-group">
            <label for="nama">Nama</label>
            <input type="text" class="form-control" id="nama" placeholder="Nama" name="nama" value="<?php echo e($user->fullname); ?>">
          </div>
          <div class="form-group">
            <label for="deskripsi">Deskripsi</label>
            <textarea class="form-control" id="deskripsi" name="deskripsi" rows="3" placeholder="Deskripsi"><?php echo e($profil->deskripsi); ?></textarea>
          </div>
          <div class="form-group">
            <label for="email">Email</label>
            <input type="email" class="form-control" id="email" name="email" value="<?php echo e($user->email); ?>" placeholder="Email">
          </div>
          <div class="form-group">
            <label for="telepon">No Telepon</label>
            <input type="tel" class="form-control" id="telepon" name="telepon" placeholder="No Telepon" value="<?php echo e($user->nohp); ?>">
          </div>

        </div>
      </div>
      <div class="col col-md-7">
        <div class="profile-card text-start p-5 second">
          <div class="row">
          <div class="col-md-6">
          <div class="form-group">
    <label for="pengalaman">Pengalaman Kerja</label>
    <div id="pengalamanContainer">
        <?php
            // Cek afakh $profil->pengalaman adalah string atau array
            if (is_string($profil->pengalaman)) {
                $pengalamanArray = json_decode($profil->pengalaman);
            } elseif (is_array($profil->pengalaman)) {
                // nek udah array
                $pengalamanArray = $profil->pengalaman;
            } else {
                // Jika bukan string atau array, atur menjadi array kosong
                $pengalamanArray = [];
            }

            $jumlahPengalaman = count($pengalamanArray);
        ?>

        <?php $__currentLoopData = $pengalamanArray; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pengalaman): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <div class="form-group d-flex align-items-center posisifix">
            <input type="text" class="form-control mb-2" name="pengalaman[]" value="<?php echo e($pengalaman); ?>" placeholder="Pengalaman Kerja">
            <button type="button" class="btn btn-danger btn-sm remove-pengalaman">-</button>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <button type="button" id="tambahPengalaman" class="btn btn-secondary mt-3">+ Pengalaman</button>
          </div>
          </div>
          <div class="col-md-6">
          <div class="form-group">
    <label for="pendidikan">Pendidikan Terakhir</label>
    <div id="pendidikanContainer">
        <div class="form-group d-flex align-items-center posisifix">
          <input type="text" class="form-control mb-2" name="riwayat_pendidikan" value="<?php echo e($user->riwayat_pendidikan); ?>" placeholder="Riwayat Pendidikan">
        </div>
    </div>
          </div>
          </div>
          </div>
          <div class="form-group">
            <label for="alamat">Alamat</label>
            <textarea class="form-control" id="alamat" name="alamat" rows="3" placeholder="Alamat"><?php echo e($user->alamat); ?></textarea>
          </div>
          <button type="submit" class="btn btn-primary">Simpan</button>
        </div>
      </div>
    </form>

  </div>
</div>
<script>
document.addEventListener("DOMContentLoaded", () => {
  activeMenu('menu2')
})

    document.getElementById('editButton').addEventListener('click', function() {
      var profilElement = document.getElementById('profil');
      var formEditElement = document.getElementById('edit');

      profilElement.classList.toggle('sembunyikan');
      formEditElement.classList.toggle('sembunyikan');
    });
// Ambil data pengalaman yang sudah ada dari input yang tersembunyi
var existingPengalaman = <?php echo json_encode($profil->pengalaman); ?>;
if (existingPengalaman) {
    existingPengalaman = JSON.parse(existingPengalaman);
}

// Ambil container untuk input pengalaman
var pengalamanContainer = document.getElementById('pengalamanContainer');

document.getElementById('tambahPengalaman').addEventListener('click', function() {
    var pengalamanContainer = document.getElementById('pengalamanContainer');
    var inputBaru = document.createElement('input');
    inputBaru.setAttribute('type', 'text');
    inputBaru.setAttribute('class', 'form-control mb-2');
    inputBaru.setAttribute('placeholder', 'Pengalaman Kerja');
    inputBaru.setAttribute('name', 'pengalaman[]');
    pengalamanContainer.appendChild(inputBaru);
});
// hapus input pengalam dan pendidikaaan
document.addEventListener('click', function(event) {
  if (event.target.classList.contains('remove-pengalaman') || event.target.classList.contains('remove-pendidikan')) {
        event.target.parentElement.remove();
  }
});
// Fungsi untuk menambah input pengalaman saat tombol tambah ditekan
document.getElementById('tambahPengalaman').addEventListener('click', function() {
    tambahkanInputPengalaman();
});

var existingPendidikan = <?php echo json_encode($profil->pendidikan); ?>;
if (existingPendidikan) {
    existingPendidikan = JSON.parse(existingPendidikan);
}

// Ambil container untuk input pendidikan
var pendidikanContainer = document.getElementById('pendidikanContainer');

document.getElementById('tambahPendidikan').addEventListener('click', function() {
    var pendidikanContainer = document.getElementById('pendidikanContainer');
    var inputBaru = document.createElement('input');
    inputBaru.setAttribute('type', 'text');
    inputBaru.setAttribute('class', 'form-control mb-2');
    inputBaru.setAttribute('placeholder', 'Riwayat Pendidikan');
    inputBaru.setAttribute('name', 'pendidikan[]');
    pendidikanContainer.appendChild(inputBaru);
});
    </script>
</body>
<?php /**PATH D:\xamppMuaz\htdocs\sistem_kesehatan_klinik\resources\views/admin/profil.blade.php ENDPATH**/ ?>